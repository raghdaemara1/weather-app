/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();

let baseUrl= 'http://api.openweathermap.org/data/2.5/weather?&units=metric&zip=';
let apiKey = '&appid=52af0e35e9374f756c76dd723507f580';

let no_zipcode=document.getElementById('zip')
const date = document.getElementById('date')
const temp = document.getElementById('temp')
const content = document.getElementById('content')

document.getElementById('generate').addEventListener('click',performAction);

function performAction(e){ 
 
  const newZip = document.getElementById('zip').value;
  const feelings = document.getElementById('feelings').value;
 
  getData(baseUrl , newZip , apiKey)
    .then(function(data){
    if(no_zipcode.value.length==0)
    alert('Eneter zip code');
  
      postData('/add' , {date:newDate,temp:data.main.temp, content:feelings})
      }).then(function (newData) {
      // call updateUI to update browser content
      updateUI()
    })


}

const postData = async (url ='', data={})=>{
  console.log(data);
  const response = await fetch(url , {
    method:'POST',
    credentials : 'same-origin',
    headers : {
      'Content-Type':'application/json'
    },
    body :JSON.stringify(data)
    
  })
}

const getData= async (baseUrl ,zip , key)=>{
  const res = await fetch(baseUrl+zip+key)
  try{
    const data = await res.json();
    return data;
  } catch(error){
    console.log("error" ,error);
  }
  
}
const updateUI = async () => {
  const request = await fetch('/all');
  try{
    const allData = await request.json();
  date.innerHTML = `Date: ${allData.date}`;
  temp.innerHTML = `Temp: ${allData.temp}`;
  content.innerHTML =` I feel: ${allData.content}`;
  }catch(error){
    console.log("error" ,error);
  }
}